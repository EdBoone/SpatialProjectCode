## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- eval = FALSE------------------------------------------------------------
#  Sys.which("make")

## ---- eval = FALSE------------------------------------------------------------
#  install.packages(c("Rcpp", "RcppEigen", "RcppArmadillo", "knitr", "rmarkdown"))

## ---- eval = FALSE------------------------------------------------------------
#  sessionInfo()

## ---- eval = FALSE------------------------------------------------------------
#  sessionInfo()

## ---- eval = FALSE------------------------------------------------------------
#  install.packages("schnellerGP_0.1.0.tar.gz", type = "source", repo = NULL)

## ---- eval = FALSE------------------------------------------------------------
#  library(flexiblas)
#  flexiblas_load_backend("/opt/intel/mkl/lib/intel64/libmkl_rt.so")
#  flexiblas_list_loaded()

## ---- eval = FALSE------------------------------------------------------------
#  install.packages(c("Rcpp", "RcppEigen", "RcppArmadillo", "knitr", "rmarkdown"))

## ---- eval = FALSE------------------------------------------------------------
#  install.packages("schnellerGP_0.1.1.tar.gz", type = "source", repo = NULL)

